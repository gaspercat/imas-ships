#!/bin/bash
javac -classpath "lib/commons-codec-1.3.jar:lib/jade.jar:src" -d bin/ src/sma/*.java
