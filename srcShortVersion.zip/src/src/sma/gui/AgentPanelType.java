package sma.gui;

public enum AgentPanelType {
	Boat,
	Port,
	None
}
