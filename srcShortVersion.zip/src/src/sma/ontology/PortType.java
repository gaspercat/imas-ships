package sma.ontology;

public enum PortType implements java.io.Serializable {
	Steady,
	Minimum,
	Medium,
	Maximum,
	Cheap,
	Expensive,
	None
}
