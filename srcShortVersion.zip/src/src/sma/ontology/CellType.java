package sma.ontology;

public enum CellType implements java.io.Serializable {
	Sea,
	Boat,
	Seafood
}
