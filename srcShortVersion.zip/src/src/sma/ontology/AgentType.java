package sma.ontology;

public enum AgentType implements java.io.Serializable {
	Boat,
	Port
}
